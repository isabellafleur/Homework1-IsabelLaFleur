package homework_1;

abstract class Animal {
	abstract void makeSound();
	abstract String getName();
	void sleep() {
		System.out.print(" i am sleeping...");
		
	}
	void baby() {
		System.out.print("AHHHH");
		
	}
	

 
}
