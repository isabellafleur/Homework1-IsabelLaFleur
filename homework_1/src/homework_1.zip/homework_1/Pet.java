package homework_1;

public record Pet(String name,String breed) {
	

}
