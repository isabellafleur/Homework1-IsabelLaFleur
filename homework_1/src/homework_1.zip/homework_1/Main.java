package homework_1;

public class Main {

	public static void main(String[] args) {
		Animal myDog = new Dog();
		
		myDog.sleep();
		
		Pet myPet = new Pet("Aang","calico" );
		System.out.println(myPet);
		

	}

}
